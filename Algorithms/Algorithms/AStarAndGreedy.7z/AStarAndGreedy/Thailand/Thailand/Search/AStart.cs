﻿using System.Collections;
using Thailand.Helpers;

namespace Thailand.Search
{
    public class AStart
    {
        public static RouteInfo FindRoute(int start, int end)
        {

            //priority queue
            PQueue queue = new PQueue();

            //visited towns
            ArrayList visited = new ArrayList();

            //define the desire route
            RouteInfo route = new RouteInfo();

            //create towns list
            route.Towns = new System.Collections.Generic.List<int>();

            //total route length
            int totalLength = 0;


            //add start to the node
            route.Towns.Add(start);
            visited.Add(start);

            //push the start neighbours to the queue
            for(int i = 0; i < RoutesManager.Length; i++)
            {
                if (RoutesManager.AdjacencyMatrix[start, i] != 0)
                {
                    var tmp = new VertexInfo();
                    tmp.Town = i;
                    tmp.Priority = RoutesManager.EvristicMatrix[i, end];
                    tmp.Distance = RoutesManager.AdjacencyMatrix[start, i];
                    queue.Push(tmp);
                }
            }


            int currentEvrestic = RoutesManager.INFINITY;

            VertexInfo currentVertex = queue.Pop();

            do
            {
                if(queue.Capacity <= 0)
                {
                    throw new System.EntryPointNotFoundException();
                }

                route.Towns.Add(currentVertex.Town);
                //add to the visited
                visited.Add(currentVertex.Town);

                for (int i = 0; i < RoutesManager.Length; i++)
                {
                    if(RoutesManager.AdjacencyMatrix[currentVertex.Town, i] != 0 && !visited.Contains((object)i))
                    {
                        VertexInfo toPush = new VertexInfo();
                        toPush.Town = i;
                        toPush.Priority = RoutesManager.EvristicMatrix[i, end];
                        toPush.Distance += RoutesManager.AdjacencyMatrix[currentVertex.Town, i];

                        queue.Push(toPush);
                    }
                }


                currentVertex = queue.Pop();

                currentEvrestic = currentVertex.Priority;


            }
            while (currentVertex.Town != end);

            route.Towns.Add(currentVertex.Town);


            return route;
        }




        #region VertexInfo

        private struct VertexInfo
        {
            public int Town;
            public int Priority;
            public int Distance;
        }

        #endregion

        #region PQueue Class

        private class PQueue
        {
            private int _capacity;

            private int _position;

            private VertexInfo[] _queue;

            public int Capacity
            {
                get
                {
                    return _position + 1;
                }
            }

            public PQueue()
            {
                this._capacity = 5;
                this._queue = new VertexInfo[this._capacity];
                this._position = -1;
            }


            public void Push(VertexInfo vertex)
            {
                if(_position + 1 < _capacity)
                {
                    _position++;
                    _queue[_position] = vertex;
                }
                else
                {
                    Reallocate();
                    Push(vertex);
                }
            }

            private void Reallocate()
            {
                _capacity *= 2;
                VertexInfo[] newQueue = new VertexInfo[_capacity];

                for(int i = 0; i <= _position; i++)
                {
                    newQueue[i] = _queue[i];
                }

                _queue = newQueue;
            }

            public VertexInfo Pop()
            {

                int min = 0;

                for(int i = 0; i <= _position; i++)
                {
                    if(_queue[i].Priority < _queue[min].Priority)
                    {
                        min = i;
                    }
                }

                VertexInfo popped = _queue[min];

                for(int i = min; i <= _position - 1; i++)
                {
                    _queue[i] = _queue[i + 1];
                }

                _position--;

                return popped;

            }


        }

        #endregion


    }
}
