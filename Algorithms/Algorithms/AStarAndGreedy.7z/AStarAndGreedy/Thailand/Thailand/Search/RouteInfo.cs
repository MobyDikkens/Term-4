﻿using System.Collections.Generic;

namespace Thailand.Search
{
    public struct RouteInfo
    {
        public List<int> Towns;
        public int Length;
    }
}
