﻿using System;
using System.Windows;
using System.Windows.Input;

namespace Thailand.Commands
{
    class GreedySearchCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;

        private Func<bool> _canExecute;

        public GreedySearchCommand(Func<bool> canExecute)
        {
            this._canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute();
        }

        public void Execute(object parameter)
        {
            MessageBox.Show("Got it");
        }
    }
}
