﻿using System;
using System.ComponentModel;
using System.Windows.Input;

namespace Thailand.ViewModels
{
    class MainWindowVM : INotifyPropertyChanged
    {
        //event fires if the property is changed
        public event PropertyChangedEventHandler PropertyChanged;

        //command to search
        public ICommand Search { get; set; }

        private string _from = null;
        private string _to = null;

        //the name of properties
        private const string FromProperty = "From";
        private const string ToProperty = "To";

        //binding properties
        public string From
        {
            get
            {
                return _from;
            }

            set
            {
                _from = value;
                PropertyChanged(this, new PropertyChangedEventArgs(FromProperty));
            }
        }

        public string To
        {
            get
            {
                return _to;
            }

            set
            {
                _to = value;
                PropertyChanged(this, new PropertyChangedEventArgs(ToProperty));
            }
        }


        public MainWindowVM()
        {
            Search = new Commands.GreedySearchCommand(() =>
            {
                return To != null && From != null;
            });
        }



    }
}
